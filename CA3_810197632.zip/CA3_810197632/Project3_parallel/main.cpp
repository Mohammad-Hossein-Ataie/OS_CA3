#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include <vector>
#include <sstream>
#include <cstring>
#include <sys/wait.h>
#include <fcntl.h>
#include <thread>
#include <fstream>
#include <bits/stdc++.h>
#include <iomanip>
#include <pthread.h>
#include <cmath>
#define NUMBER_OF_THREADS 4
using namespace std;

struct thread_data
{
    string file_name;
    vector<vector<long double>> data;
    vector<int> labels;
    vector<int> states;
    vector<string>name;
    float mean = 0;
    float standardDev = 0;
    float variance,variance0 = 0;
    long total;
    int correct = 0;
    int number = 0;
    int numofOnes, numofZeros =0;
    int totalzeros = 0;
};
struct thread_data thread_data_array[NUMBER_OF_THREADS];
long prefered_price;
vector<vector<long double>> weights;

void* read_file(void* data)
{
    string line = "";
    stringstream temp_line(ios::in | ios::out);
    string temp_str = "";
    long double temp_double = 0;
	struct thread_data* my_data = (struct thread_data*) data;
	

    ifstream file_dataset(my_data->file_name,ios::in | ios::out);//
    //cout<<path <<endl;
    getline(file_dataset,line);
    std::replace(line.begin(),line.end(), ',', ' ');
    temp_line.clear();
    temp_line<<line<<endl;
    while(temp_line >> temp_str){
        my_data->name.push_back(temp_str);
        //cout<<temp_str<<endl;
    }
    while(getline(file_dataset,line)){
        vector<long double>v_temp;
        std::replace(line.begin(),line.end(), ',', ' ');
        temp_line.clear();
        temp_line<<line;
        //cout<<line<<endl;
        while(temp_line >> temp_double){//
            //cout<<temp_double<<endl;
            v_temp.push_back(temp_double);
        }
        my_data->data.push_back(v_temp);
    }
	pthread_exit(NULL);
}
void* Put_label(void* data)
{
    struct thread_data* my_data = (struct thread_data*) data;
    //cout << my_data->data.size() << endl;
    for (int j = 0; j < my_data->data.size(); j++){
        if (prefered_price > my_data->data[j][8])
        {
            my_data->labels.push_back(0);
        }
        else
        {
            my_data->labels.push_back(1);
        }
    }
	pthread_exit(NULL);
}

void* Calc_meanSD(void* data)
{
    float counter = 0;
    float variance = 0;
    struct thread_data* my_data = (struct thread_data*) data;//
    for (int i = 0; i < my_data->data.size(); i++)
    { 
        if(my_data->labels[i] == 1)
        {
            counter ++;
            my_data->total += my_data->data[i][5];
        }
        else
        {
            my_data->numofZeros ++;
            my_data->totalzeros += my_data->data[i][5];
        }
    }
    for (int i = 0; i < my_data->data.size(); i++)
    {
        if(my_data->labels[i] == 1)
        {
            my_data->variance += (my_data->data[i][5])*(my_data->data[i][5]);
        }
        else
        {
            my_data->variance0 += (my_data->data[i][5])*(my_data->data[i][5]);
        }
    }
    my_data->numofOnes = counter;
	pthread_exit(NULL);
}

void* calculate(void* data)
{
    struct thread_data* my_data = (struct thread_data*) data;
    float minbound = my_data-> mean - my_data->standardDev;
    float maxbound = my_data->mean + my_data->standardDev;
    for (int i = 0; i < my_data->data.size(); i++) { 
        if(minbound < my_data->data[i][5])
        {
            if(my_data->data[i][5]<maxbound)
            {
                my_data->states.push_back(1);
            }
            else
            {
                my_data->states.push_back(0);
            }
        }
        else
        {
            my_data->states.push_back(0);
        }
    }
    for(int i = 0; i < my_data->data.size(); i++)
    {
        my_data->number ++;
        if(my_data->states[i] == my_data->labels[i])
        {
            my_data->correct ++;
        }
    }
	pthread_exit(NULL);
}




int main(int argc, const char** argv){
    pthread_t threads[NUMBER_OF_THREADS];
    int* thread_ids[NUMBER_OF_THREADS];
    char*p;
    prefered_price = strtol(argv[2],&p,10);
    string path_dataset_0 = "/dataset_0.csv";
    string path_dataset_1 = "/dataset_1.csv";
    string path_dataset_2 = "/dataset_2.csv";
    string path_dataset_3 = "/dataset_3.csv";
    path_dataset_0 = argv[1] + path_dataset_0;
    path_dataset_1 = argv[1] + path_dataset_1;
    path_dataset_2 = argv[1] + path_dataset_2;
    path_dataset_3 = argv[1] + path_dataset_3;
    void* status;
    vector<string> name_weights;
    
    int return_code = 0;
    for(int tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
        if(tid == 0)thread_data_array[tid].file_name = path_dataset_0;
        if(tid == 1)thread_data_array[tid].file_name = path_dataset_1;
        if(tid == 2)thread_data_array[tid].file_name = path_dataset_2;
        if(tid == 3)thread_data_array[tid].file_name = path_dataset_3;


		return_code = pthread_create(&threads[tid], NULL, read_file,
				(void*)&thread_data_array[tid]);
		if (return_code)
		{
			cout << "error : return code from pthread_create() is :" << return_code <<endl;
			exit(-1);
		}
	}

    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_join(threads[tid], &status);
		if (return_code)
		{
			cout<<"error : pthread_join() after reading file is" <<return_code << endl;
            exit(-1);
		}
	}
    for(int tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_create(&threads[tid], NULL, Put_label,(void*)&thread_data_array[tid]);
		if (return_code)
		{
			cout << "error : return code from pthread_create() is :" << return_code <<endl;
			exit(-1);
		}
	}
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_join(threads[tid], &status);
		if (return_code)
		{
			cout<<"error : pthread_join() after Put_label  is" <<return_code << endl;
            exit(-1);
		}
	}

    for(int tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_create(&threads[tid], NULL, Calc_meanSD,(void*)&thread_data_array[tid]);
		if (return_code)
		{
			cout << "error : return code from pthread_create() is :" << return_code <<endl;
			exit(-1);
		}
	}
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_join(threads[tid], &status);
		if (return_code)
		{
			cout<<"error : pthread_join() after Calc_meanSD  is" <<return_code << endl;
            exit(-1);
		}
	}
    /*
    long total = 0;
    float counter = 0;
    float variance = 0;
    float mean = 0;
    float standardDev = 0;
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
    {
        total += thread_data_array[tid].mean; 
    }
    mean = total/ NUMBER_OF_THREADS;
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
    {
        variance += (thread_data_array[tid].mean - mean)*(thread_data_array[tid].mean - mean);
    }
    variance = variance / NUMBER_OF_THREADS;
    cout << mean << endl;
    float tempe = sqrt(variance);
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
    {
        thread_data_array[tid].mean = mean;
        thread_data_array[tid].standardDev = tempe;
    }
*/
    float mean = 0;
    float SD = 0;
    float variance = 0;
    float counter = 0;
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++){
        counter += thread_data_array[tid].numofOnes;
        mean += thread_data_array[tid].total;
    }
    mean = mean / counter;
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
    {
        variance += thread_data_array[tid].variance;
    }
    
    variance = variance / counter ;
    variance = variance - (mean*mean);
    float tempe = sqrt(variance);
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
    {
        thread_data_array[tid].mean = mean;
        thread_data_array[tid].standardDev = tempe;
    }



    for(int tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_create(&threads[tid], NULL,calculate,(void*)&thread_data_array[tid]);
		if (return_code)
		{
			cout << "error : return code from pthread_create() is :" << return_code <<endl;
			exit(-1);
		}
	}
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++)
	{
		return_code = pthread_join(threads[tid], &status);
		if (return_code)
		{
			cout<<"error : pthread_join() after calculate  is" <<return_code << endl;
            exit(-1);
		}
    }

    int correct = 0;
    int number = 0;
    for(long tid = 0; tid < NUMBER_OF_THREADS; tid++){
        correct += thread_data_array[tid].correct;
        number += thread_data_array[tid].number;
    }
    double answer = (double)correct/(double)number * (double)100;
    cout<<"Accuracy: ";
    cout << std::fixed << std::setprecision(2) << answer;
    cout<< "%"<<endl;
    return 0;
}