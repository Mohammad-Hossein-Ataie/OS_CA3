#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include <vector>
#include <sstream>  
#include <cstring>
#include <sys/wait.h>
#include <fcntl.h>
#include <thread>
#include <fstream>
#include <bits/stdc++.h>
#include <iomanip>
#include <cmath>

using namespace std;
int main(int argc, const char** argv) 
{
    //cout << argv[1] << endl;
    char*p;
    long prefered_price = strtol(argv[2],&p,10);
    vector<string> name_dataset;
    vector<vector<long double>> data;
    vector<int> labels;
    vector<int> states;
    string line = "";
    long double temp_double = 0;
    string temp_str = "";
    stringstream temp_line(ios::in | ios::out);
    string path_dataset = "dataset.csv";
    path_dataset = argv[1] + path_dataset;
    ifstream file_dataset(path_dataset,ios::in | ios::out);
    //cout<<path <<endl;
    getline(file_dataset,line);
    std::replace(line.begin(),line.end(), ',', ' ');
    temp_line.clear();
    temp_line<<line;
    int numOfLines = 0;
    while(temp_line >> temp_str){
        name_dataset.push_back(temp_str);
        //cout<<temp_str<<endl;
    }
    while(getline(file_dataset,line)){
        numOfLines ++;
        vector<long double>v_temp;
        std::replace(line.begin(),line.end(), ',', ' ');
        temp_line.clear();
        temp_line<<line;
        //cout<<line<<endl;
        while(temp_line >> temp_double){
            //cout<<temp_double<<endl;
            v_temp.push_back(temp_double);
        }
        data.push_back(v_temp);
    }
    //cout << numOfLines << endl;
    //cout << prefered_price << endl;
    for (int j = 0; j < numOfLines; j++)
    {
        //cout << data[j][8]<< endl;
        if(prefered_price > data[j][8])
        {
            labels.push_back(0);
        }
        else
        {
            labels.push_back(1);
        }
    }
    double total0 = 0;
    double total1 = 0;
    int numof1s = 0;
    int numof0s = 0;
    for(int i = 0; i < numOfLines; i++)
    {
        if(labels[i] == 1)
        {
            numof1s ++;
            total1 += data[i][5];            
        }
        else
        {
            numof0s ++;
            total0 += data[i][5];
        }
    }
    float mean1 = total1/numof1s;
    float mean0 = total0/numof0s;
    float variance0 = 0;
    float variance1 = 0;
    for(int k = 0; k < numOfLines; k++)
    {
        if(labels[k] == 1)
        {
            variance1 += (data[k][5] - mean1)*(data[k][5] - mean1);
        }
        else if(labels[k] == 0)
        {
            variance0 += (data[k][5] - mean1)*(data[k][5] - mean1);
        }
    }
    variance1 = variance1 / numof1s;
    variance0 = variance0 / numof0s;
    //cout << variance << endl;
    float standardDev1 = sqrt(variance1);
    float standardDev0 = sqrt(variance0);
    //cout << standardDev << endl;
float minbound = mean1 - standardDev1;
float maxbound = mean1 + standardDev1;
    //cout << minbound << endl;
    //cout << maxbound << endl;
    for(int m = 0; m < numOfLines; m++)
    {
        int temp = data[m][5];
        if(minbound < temp)
        {
            if (temp < maxbound)
            {
                //cout << "11" << endl;
                states.push_back(1);
            }
            else
            {
                //cout << "00" << endl;
                states.push_back(0);
            }
        }
        else
        {
            //cout << "00" << endl;
            states.push_back(0);
        }
    }
    int corrects = 0;
    for(int n = 0; n < numOfLines; n++)
    {
        if(states[n] == labels[n])
        {
            corrects ++;
        }
    }

    float accuracy = (float)corrects / (float)numOfLines *(float)100;
    cout<<"Accuracy: ";
    cout << std::fixed << std::setprecision(2) << accuracy;
    cout<< "%"<<endl;
}
